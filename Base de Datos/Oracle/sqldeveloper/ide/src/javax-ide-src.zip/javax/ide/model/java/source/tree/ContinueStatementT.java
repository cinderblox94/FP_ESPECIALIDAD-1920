/*
 * @(#)ContinueStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A continue statement. JLS3 14.16. <p/>
 *
 * @author Andy Yu
 * */
public interface ContinueStatementT
  extends SimpleStatementT
{
}
