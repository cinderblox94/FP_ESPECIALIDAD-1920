/*
 * @(#)StatementLabelT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A label on a labeled statement. JLS3 14.7.
 *
 * @author Andy Yu
 * */
public interface StatementLabelT
  extends Tree, HasNameT
{
  // ----------------------------------------------------------------------

  public final static StatementLabelT[] EMPTY_ARRAY =
    new StatementLabelT[ 0 ];


  // ----------------------------------------------------------------------
}
