/*
 * @(#)ConditionalStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * Common supertype for compound statements having (requiring) a
 * conditional expression. This includes: do, if, while. Note that a
 * for expression is not considered to be a conditional statement. <p/>
 *
 * @author Andy Yu
 * */
public interface ConditionalStatementT
  extends CompoundStatementT
{
  // ----------------------------------------------------------------------
}
