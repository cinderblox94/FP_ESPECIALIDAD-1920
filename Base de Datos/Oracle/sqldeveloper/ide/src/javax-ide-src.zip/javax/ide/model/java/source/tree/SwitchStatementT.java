/*
 * @(#)SwitchStatementT.java
 */

package javax.ide.model.java.source.tree;

/**
 * A switch statement. JLS3 14.11.
 *
 * @author Andy Yu
 * */
public interface SwitchStatementT
  extends CompoundStatementT
{
  // ----------------------------------------------------------------------
}
