/**
 * Ejemplo01.java
*
 * @author Pepe Perez
 * @version 1.00 2017/5/10
 */
package com.pepe.perez.ejemplos;
public class Ejemplo01 {
    public Ejemplo01()
    {
        System.out.println("Hola Mundo");
        System.out.println("By Pepe Perez ");
    }
    public static void main (String[] args)
    {
        new Ejemplo01();
    }
}
