package explicacion;

public class Ejemplo1 {

	public static void main(String[] args) {
		int x ;
	    
		System.out.println(" Primer ejemplo");
	    
	    for (x = 1; x < 20; x++) {
	    	System.out.print(" -");
	    }
	    System.out.println();    
	   
	    System.out.println(" Segundo ejemplo");
	 
	    for (x = 1; x < 20; x++) {
	    	System.out.print(" -");
	    }
	    System.out.println();    
	   
	    System.out.println(" Tercer ejemplo");
		 
	    for (x = 1; x < 20; x++) {
	    	System.out.print(" -");
	    }
	    System.out.println();  

	}

}
